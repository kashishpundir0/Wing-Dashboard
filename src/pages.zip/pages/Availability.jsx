import React, { useState, useEffect, useCallback } from 'react';
// Added 'Save' below
import { Plus, Trash2, Save, Calendar as CalendarIcon, Clock, AlertCircle, X, Loader2, Edit2, CheckCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import toast from 'react-hot-toast';
import { getInterviewerAvailability, setAvailability, updateAvailability, deleteAvailability } from '../api/availabilityApi';

const Availability = () => {
  const interviewerId = localStorage.getItem('userId') || "698c3da24b44a31163b5c117";

  const [loading, setLoading] = useState(true);
  const [dateSlots, setDateSlots] = useState([]);
  const [currentWeekStart, setCurrentWeekStart] = useState(new Date());

  // Weekly Template (Recurring)
  const [weeklySlots, setWeeklySlots] = useState([
    { id: 1, day: 'Monday', start: '09:00', end: '12:00' },
  ]);

  // Form States
  const [selectedDate, setSelectedDate] = useState('');
  const [tempTimeSlots, setTempTimeSlots] = useState([]);
  const [currentTime, setCurrentTime] = useState({ start: '10:30', end: '11:00' });

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const getWeekDates = (startDate) => {
    const start = new Date(startDate);
    const day = start.getDay();
    const diff = start.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(start.setDate(diff));

    return daysOfWeek.map((_, index) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + index);
      return d.toISOString().split('T')[0];
    });
  };

  const weekDates = getWeekDates(currentWeekStart);

  const fetchAvailability = useCallback(async () => {
    setLoading(true);
    try {
      const response = await getInterviewerAvailability(interviewerId);
      if (response.success) setDateSlots(response.data || []);
    } catch (error) {
      toast.error("Failed to sync directory");
    } finally {
      setLoading(false);
    }
  }, [interviewerId]);

  useEffect(() => { fetchAvailability(); }, [fetchAvailability]);

  const handleFinalProvision = async () => {
    if (!selectedDate || tempTimeSlots.length === 0) return toast.error("Select date and add slots");
    const payload = {
      interviewerId,
      date: selectedDate,
      timeSlots: tempTimeSlots.map(s => ({ ...s, isBooked: false }))
    };
    try {
      setLoading(true);
      const existing = dateSlots.find(s => s.date === selectedDate);
      existing ? await updateAvailability(existing._id, payload) : await setAvailability(payload);
      toast.success("Schedule Provisioned");
      setTempTimeSlots([]);
      fetchAvailability();
    } catch (error) { toast.error("Operation failed"); }
    finally { setLoading(false); }
  };

  return (
    <div className="w-full pt-4 pb-20 animate-in fade-in duration-500">

      {/* HEADER & WEEK NAVIGATION */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-8 bg-white p-8 rounded-4xl border border-slate-100 shadow-sm">
        <div>
          <h3 className="text-3xl font-black text-[#1F1F2E]">Master Schedule</h3>
          <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest mt-1 italic">Combined Template & Date Intel</p>
        </div>

        <div className="flex items-center gap-4 bg-slate-50 p-2 rounded-2xl border border-slate-100">
          <button onClick={() => { const d = new Date(currentWeekStart); d.setDate(d.getDate() - 7); setCurrentWeekStart(d); }} className="p-2 hover:bg-white rounded-xl shadow-sm transition-all"><ChevronLeft size={20} /></button>
          <div className="px-4 text-center">
            <p className="text-[9px] font-black text-slate-400 uppercase">Current View</p>
            <p className="text-sm font-bold text-[#1F1F2E]">{weekDates[0]} — {weekDates[6]}</p>
          </div>
          <button onClick={() => { const d = new Date(currentWeekStart); d.setDate(d.getDate() + 7); setCurrentWeekStart(d); }} className="p-2 hover:bg-white rounded-xl shadow-sm transition-all"><ChevronRight size={20} /></button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">

        {/* LEFT: INTEGRATED WEEKLY VIEW */}
        <div className="xl:col-span-2 bg-white rounded-4xl border border-slate-100 shadow-sm p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Clock className="text-indigo-600" />
              <h4 className="text-xl font-bold text-[#1F1F2E]">Active Timeline</h4>
            </div>
            {loading && <Loader2 className="animate-spin text-indigo-600" size={20} />}
          </div>

          <div className="space-y-3">
            {daysOfWeek.map((day, index) => {
              const calendarDate = weekDates[index];
              const dateSpecificIntel = dateSlots.find(s => s.date === calendarDate);

              return (
                <div key={day} className={`flex flex-col md:flex-row md:items-center gap-6 p-6 rounded-3xl border transition-all ${dateSpecificIntel ? 'bg-indigo-50/30 border-indigo-100 shadow-sm' : 'bg-white border-transparent hover:bg-slate-50'}`}>

                  <div className="w-32">
                    <p className="text-[9px] font-black text-indigo-500 uppercase tracking-widest">{calendarDate}</p>
                    <p className="font-black text-[#1F1F2E] text-lg leading-tight uppercase">{day}</p>
                  </div>

                  <div className="flex-1 flex flex-wrap gap-3">
                    {weeklySlots.filter(s => s.day === day).map(slot => (
                      <div key={slot.id} className="flex items-center bg-white border border-slate-200 px-3 py-2 rounded-xl gap-3 shadow-xs">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">Template</span>
                        <span className="text-xs font-black text-slate-700">{slot.start}-{slot.end}</span>
                      </div>
                    ))}

                    {dateSpecificIntel && dateSpecificIntel.timeSlots.map((slot, i) => (
                      <div key={i} className="flex items-center bg-[#1F1F2E] text-white px-4 py-2 rounded-xl gap-3 shadow-md animate-in zoom-in-95">
                        <CheckCircle size={12} className="text-emerald-400" />
                        <span className="text-xs font-black tracking-wider">{slot.startTime} — {slot.endTime}</span>
                      </div>
                    ))}

                    {!dateSpecificIntel && weeklySlots.filter(s => s.day === day).length === 0 && (
                      <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest italic">No Intel Set</span>
                    )}
                  </div>

                  <button
                    onClick={() => { setSelectedDate(calendarDate); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                    className="p-3 bg-white border border-slate-100 rounded-2xl text-slate-400 hover:text-indigo-600 hover:shadow-md transition-all"
                  >
                    <Plus size={18} />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT: PROVISIONING PANEL */}
        <div className="xl:col-span-1 space-y-6">
          <div className="bg-white rounded-4xl border border-slate-100 shadow-2xl p-8 sticky top-6">
            <h4 className="text-xl font-bold text-[#1F1F2E] mb-6 flex items-center gap-2">
              <CalendarIcon className="text-indigo-600" size={20} /> Provisioning
            </h4>

            <div className="space-y-6">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Target Date</label>
                <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="w-full p-4 rounded-2xl bg-slate-50 border-none font-bold text-[#1F1F2E] shadow-inner" />
              </div>

              <div className="bg-indigo-50/50 p-6 rounded-3xl border border-indigo-100">
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <input type="time" value={currentTime.start} onChange={(e) => setCurrentTime({ ...currentTime, start: e.target.value })} className="p-3 rounded-xl border-none font-bold text-sm shadow-sm" />
                  <input type="time" value={currentTime.end} onChange={(e) => setCurrentTime({ ...currentTime, end: e.target.value })} className="p-3 rounded-xl border-none font-bold text-sm shadow-sm" />
                </div>
                <button onClick={() => { setTempTimeSlots([...tempTimeSlots, { startTime: currentTime.start, endTime: currentTime.end }]); toast.success("Added to queue"); }} className="w-full py-3 bg-white text-indigo-600 rounded-xl font-black text-[10px] uppercase tracking-widest border border-indigo-200">Add to queue</button>
              </div>

              {tempTimeSlots.length > 0 && (
                <div className="space-y-2">
                  {tempTimeSlots.map((s, i) => (
                    <div key={i} className="flex justify-between p-3 bg-white border border-slate-100 rounded-xl shadow-sm">
                      <span className="text-xs font-bold">{s.startTime}-{s.endTime}</span>
                      <button onClick={() => setTempTimeSlots(tempTimeSlots.filter((_, idx) => idx !== i))} className="text-red-400"><X size={14} /></button>
                    </div>
                  ))}
                </div>
              )}

              <button disabled={!selectedDate || tempTimeSlots.length === 0 || loading} onClick={handleFinalProvision} className="w-full py-5 bg-[#1F1F2E] text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl hover:bg-black transition-all flex items-center justify-center gap-3">
                <Save size={16} /> {loading ? 'Saving...' : 'Commit to Schedule'}
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Availability;